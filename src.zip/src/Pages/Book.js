import React from 'react';
import Rating from './SellerPages/Rating';

export default function Book(props) {
    const {book} = props;
    return (
        <div>
            
<div key={book._id} className="card">
<a href={`/book/${book._id}`} >
<img className="medium" src={book.image} alt={book.name} />
</a>
<div className="card-body">
<a href={`/book/${book._id}`} >
  <h3 className="BookName">{book.name}</h3>
</a>
<a href="Shop01.html">
  <h3 className="ShopName">{book.shopname} </h3>
</a>
<Rating 
rating={book.rating}
numReviews={book.numReviews}
></Rating>
<div className="price">TK {book.price}</div>
</div>
</div>
        </div>
    )
}

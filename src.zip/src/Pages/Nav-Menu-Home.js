import React from 'react';
import '../App.css';
import {Link} from 'react-router-dom';
function Nav() {
    const navStyle = {
        color : 'white'
    }
  return (
      <nav className="header">
          <ul className = "nav-links">
              <Link style={navStyle}   to='/' >
            <li className="dropbtn" className="navHome" className="dropdown" >Home</li>
            </Link>
          <Link style={navStyle} to='/AboutUs'>
              <li>
              <li className="dropbtn" className="dropdown">
                  About us
          <div className="dropdown-content">
              <Link  to='/Team'>
            
            <li>Team</li>
            </Link>
            <Link  to='/Contact'>
            <li >Contact</li>
            </Link>
            </div>
              </li>
		</li>
		</Link>
              <Link style={navStyle}  to='/Books'>
               <li>
               <li className="dropbtn" className="Books" className="dropdown">
                   Books
          <div className="dropdown-content">
              <Link  to='/Shop'>
            
            <li>Shops</li>
            </Link>
          </div>
          </li>
              </li>
              </Link>
          <Link style={navStyle} to='/JoinUs'>
              <li>
              <li className="dropbtn" className="dropdown">
                  Join us
          <div className="dropdown-content">
              <Link  to='/SignUp'>
            
            <li>SignUp</li>
            </Link>
            <Link  to='/LogIn'>
            <li >LogIn</li>
            </Link>
            </div>
              </li>
		</li>
		</Link>
          </ul>
      </nav>
  );
}
 
export default Nav;

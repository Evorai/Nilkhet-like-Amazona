import React, { Component } from 'react'

export default class ShopProfile extends Component {
    render() {
        return (
            <div>
                ShopProfile
            </div>
        )
    }
}

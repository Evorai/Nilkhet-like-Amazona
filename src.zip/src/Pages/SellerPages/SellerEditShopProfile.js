import React, { Component } from 'react'

export default class SellerEditShopProfile extends Component {
    render() {
        return (
            <div>
                SellerEditShopProfile
            </div>
        )
    }
}

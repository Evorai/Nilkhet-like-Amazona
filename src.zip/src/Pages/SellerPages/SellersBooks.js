import React, { Component } from 'react'

export default class SellersBooks extends Component {
    render() {
        return (
            <div>
                SellerBooks
            </div>
        )
    }
}

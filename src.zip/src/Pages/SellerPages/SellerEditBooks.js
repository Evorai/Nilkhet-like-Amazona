import React, { Component } from 'react'

export default class SellerEditBooks extends Component {
    render() {
        return (
            <div>
                SellerEditBooks
            </div>
        )
    }
}

import React, { Component } from 'react';
import '../App.css';


export default class Nilkhet extends Component {
    render() {
        return (<div>
            <h1>Shops</h1>
        </div>
            
        )
    }
}

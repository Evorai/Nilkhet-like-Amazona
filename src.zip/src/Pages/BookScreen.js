import React from 'react'
import Rating from './SellerPages/Rating'
import data from '../data'
import {Link} from 'react-router-dom'

export default function BookScreen() {
    return (
        <div>
        <h1>BookScreen</h1>
        </div>
    )
}

import React from 'react';
import '../App.css';
import './Books.css';
import data from './data';
import Book from './Book';
import { BrowserRouter, Route} from 'react-router-dom';
 
function Books() {
  return (
  <BrowserRouter>
  <div>
    <h1>Books</h1>  
<div>
<div className="Nilkhet Books">
<div className="row center">
{
data.books.map((book) => ( 
  <Book key={book._id} book={book} ></Book>
))
}
</div>
</div>
</div>
</div>
</BrowserRouter>
  );
}
 
export default Books;
 

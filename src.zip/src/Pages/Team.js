import React, { Component } from 'react'

export default class Team extends Component {
    render() {
        return (
            <div>
                <h1>Team</h1>
            </div>
        )
    }
}

import React, { Component } from 'react';
import './JoinUs.css';

export default class LogIn extends Component {
    render() {
        return (
            <div>
                   <form>
      <div>
        <label for="number">Phone Number</label> 
      <input type="number" placeholder="Enter Phone Number" accesskey="p"  name="number" id="pNumber" required/>
      </div>
      <div>
      <label for="psw">Password</label>
      <input type="password" placeholder="Enter Password"  accesskey="w"  id="password" name="psw" required />
      <input type="checkbox" onclick="showPassword()"/>Show Password
      </div>
      <div class="clearfix">
        <button type="button" class="cancelbtn">Cancel</button>
        <button type="submit" class="signupbtn"  accesskey="Enter" onclick="validate()"  >Log In</button>
      </div>
    </form>

            </div>
        )
    }
}

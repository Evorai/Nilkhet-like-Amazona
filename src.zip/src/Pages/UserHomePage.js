import React, { Component } from 'react'

export default class UserHomePage extends Component {
    render() {
        return (
            <div>
                UserHomePage
            </div>
        )
    }
}

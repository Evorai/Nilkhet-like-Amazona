import React from 'react';
import './HomePage.css';
import Nav from './Nav-Menu-Home';
import AboutUs from './AboutUs';
import Books from './Books';
import Team from './Team';
import Contact from './Contact';
import JoinUs from './JoinUs';
import Shop from './Shop';
import SignUp from './SignUp';
import LogIn from './LogIn';
import SellerSignUp from './SellerSignUp';
import SellerHomePage from './SellerHomePage';
import UserSignUp from './UserSignUp';
import SellerEditBooks from './SellerPages/SellerEditBooks';
import SellerPanel from './SellerPages/SellerPanel';
import SellerEditShopProfile from './SellerPages/SellerEditShopProfile';
import SellersBooks from './SellerPages/SellersBooks';
import ShopProfile from './SellerPages/ShopProfile';
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom';
import BookScreen from './BookScreen';
 
function App() {
  
  return (
    <Router>
    <div className="App">
      <Nav /> 
      <Switch>
      <Route exact path="/" component={Home} />  
      <Route exact path="/AboutUs" component={AboutUs} />
      <Route path="/Books" component={Books} />
      <Route path="/Team" component={Team} />
      <Route path="/JoinUs" component={JoinUs} />
      <Route path="/Contact" component={Contact} />
      <Route exact path="/Shop" component={Shop} />
      <Route exact path="/SignUp" component={SignUp} />
      <Route exact path="/LogIn" component={LogIn} />
      <Route exact path="/SellerSignUp" component={SellerSignUp} />
      <Route exact path="/UserSignUp" component={UserSignUp} />
      <Route exact path="/SellerHomePage" component={SellerHomePage} />
      <Route exact path="/SellerPages/SellerEditBooks" component={SellerEditBooks} />
      <Route exact path="/SellerPages/SellerPanel" component={SellerPanel} />
      <Route exact path="/SellerPages/SellerEditShopProfile" component={SellerEditShopProfile} />
      <Route exact path="/SellerPages/SellersBooks" component={SellersBooks} />
      <Route exact path="/SellerPages/ShopProfile" component={ShopProfile} />
      <Route exact path="/Book/:id" component={BookScreen} />
      </Switch>
    </div>
    </Router>
  );
}
function Home() {
  return <div>
  <h1>Home</h1>
    <footer>
      <h3>
        All Right reserved!!!
      </h3>
    </footer>
    </div>
};
export default App;

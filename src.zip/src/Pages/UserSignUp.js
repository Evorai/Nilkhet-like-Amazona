import React, { Component } from 'react';
import {Link} from 'react-router-dom';

export const USER_SIGNIN_REQUEST = 'USER_SIGNIN_REQUEST';
export const USER_SIGNIN_SUCCESS = 'USER_SIGNIN_SUCCESS';
export const USER_SIGNIN_FAIL = 'USER_SIGNIN_FAIL';
export const USER_SIGNIN_SIGNOUT = 'USER_SIGNIN_SIGNOUT';

export default class UserSignUp extends Component {
    render() {
        return (
            <div>
                
            <div>
                <h1>UserSignUp</h1>
      <div class="clearfix">
        <button type="button" class="cancelbtn">Cancel</button>
	<Link to="./SellerHomePage">
        <button type="submit" class="signupbtn"  accesskey="Enter">SignUp</button>
        </Link>
      </div>

            </div>
            </div>
        )
    }
}

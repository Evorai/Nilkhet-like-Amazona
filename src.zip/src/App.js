import React from 'react';
import './App.css';
import HomePage from './Pages/HomePage';
 
function App() {
  
  return (
    <HomePage />
  );
}
export default App;
